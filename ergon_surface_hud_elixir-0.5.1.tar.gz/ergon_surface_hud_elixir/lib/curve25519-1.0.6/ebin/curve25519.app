{application,curve25519,
             [{config_mtime,1781908250},
              {optional_applications,[]},
              {applications,[kernel,stdlib,elixir,crypto]},
              {description,"Curve25519 Diffie-Hellman functions\n"},
              {modules,['Elixir.Curve25519']},
              {registered,[]},
              {vsn,"1.0.6"}]}.
