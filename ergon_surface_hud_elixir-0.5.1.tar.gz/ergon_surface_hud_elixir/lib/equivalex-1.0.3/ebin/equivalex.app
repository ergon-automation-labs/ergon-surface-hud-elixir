{application,equivalex,
             [{config_mtime,1781908250},
              {optional_applications,[]},
              {applications,[kernel,stdlib,elixir]},
              {description,"constant time polymorphic comparisons\n"},
              {modules,['Elixir.Equivalex']},
              {registered,[]},
              {vsn,"1.0.3"}]}.
