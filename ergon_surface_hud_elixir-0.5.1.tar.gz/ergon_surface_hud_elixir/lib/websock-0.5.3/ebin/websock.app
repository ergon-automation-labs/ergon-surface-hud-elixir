{application,websock,
             [{config_mtime,1781908251},
              {optional_applications,[]},
              {applications,[kernel,stdlib,elixir]},
              {description,"A specification for WebSocket connections"},
              {modules,['Elixir.WebSock']},
              {registered,[]},
              {vsn,"0.5.3"}]}.
